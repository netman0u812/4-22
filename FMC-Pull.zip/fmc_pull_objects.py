#!/usr/bin/env python3
"""fmc_pull_objects.py v1.1 — see --help for full docs"""
VERSION = '1.1'

import argparse, json, os, sys, time, urllib.request, urllib.error
import ssl, getpass
from datetime import datetime, timezone

OBJECT_ENDPOINTS = [
    ('object/networks',           'fmc_network_objects.json',  'Network (subnet/CIDR) objects'),
    ('object/hosts',              'fmc_host_objects.json',     'Host (/32) objects'),
    ('object/ranges',             'fmc_range_objects.json',    'IP range objects'),
    ('object/networkgroups',      'fmc_network_groups.json',   'Network group objects'),
    ('object/portobjectgroups',   'fmc_port_groups.json',      'Port group objects'),
    ('object/protocolportobjects','fmc_port_objects.json',     'TCP/UDP port objects'),
    ('object/icmpv4objects',      'fmc_icmp_objects.json',     'ICMPv4 objects'),
    ('object/securityzones',      'fmc_security_zones.json',   'Security zones'),
    ('object/fqdns',              'fmc_fqdn_objects.json',     'FQDN objects'),
]
ACP_ENDPOINT = 'policy/accesspolicies'


def log(msg='', indent=0):
    print('  ' * indent + msg, flush=True)


class FMCClient:
    TOKEN_TTL = 1700

    def __init__(self, host, username, password, verify_ssl=True, domain=''):
        self.base     = f'https://{host}'
        self.user     = username
        self.passwd   = password
        self.token    = None
        self.domain   = domain or None
        self.token_ts = 0
        ctx = ssl.create_default_context()
        if not verify_ssl:
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
        self.ctx = ctx

    def _req(self, method, url):
        headers = {'Content-Type': 'application/json', 'Accept': 'application/json'}
        if self.token:
            headers['X-auth-access-token'] = self.token
        req = urllib.request.Request(url, headers=headers, method=method)
        try:
            with urllib.request.urlopen(req, context=self.ctx, timeout=60) as resp:
                raw = resp.read()
                return resp.status, json.loads(raw) if raw else {}
        except urllib.error.HTTPError as e:
            return e.code, {'error': e.read().decode('utf-8', errors='replace')}
        except urllib.error.URLError as e:
            raise ConnectionError(f'Cannot reach {self.base}: {e.reason}')

    def authenticate(self):
        import base64
        url  = f'{self.base}/api/fmc_platform/v1/auth/generatetoken'
        cred = base64.b64encode(f'{self.user}:{self.passwd}'.encode()).decode()
        req  = urllib.request.Request(url, method='POST')
        req.add_header('Authorization', f'Basic {cred}')
        req.add_header('Content-Type', 'application/json')
        try:
            with urllib.request.urlopen(req, context=self.ctx, timeout=30) as resp:
                self.token    = resp.headers.get('X-auth-access-token')
                detected      = resp.headers.get('DOMAIN_UUID')
                if not self.domain and detected:
                    self.domain = detected
                self.token_ts = time.time()
                if not self.token:
                    raise ValueError('No X-auth-access-token in response headers')
        except urllib.error.HTTPError as e:
            raise ValueError(f'Auth failed HTTP {e.code}: {e.read().decode()}')
        log(f'Auth OK  domain={self.domain}', indent=2)

    def _refresh(self):
        if time.time() - self.token_ts > self.TOKEN_TTL:
            log('Token nearing expiry — refreshing...', indent=2)
            self.authenticate()

    def get_version(self):
        s, d = self._req('GET', f'{self.base}/api/fmc_platform/v1/info/serverversion')
        if s == 200:
            items = d.get('items', [])
            if items:
                return items[0].get('serverVersion', 'unknown')
        return 'unknown'

    def fetch_all(self, endpoint, limit=1000):
        self._refresh()
        base_url = f'{self.base}/api/fmc_config/v1/domain/{self.domain}/{endpoint}'
        items, offset = [], 0
        while True:
            url = f'{base_url}?offset={offset}&limit={limit}&expanded=true'
            status, data = self._req('GET', url)
            if status == 404:
                return []
            if status != 200:
                log(f'WARNING: HTTP {status} for {endpoint}', indent=2)
                return items
            batch = data.get('items', [])
            items.extend(batch)
            total = data.get('paging', {}).get('count', len(batch))
            if offset + len(batch) >= total or not batch:
                break
            offset += len(batch)
            self._refresh()
        return items


def build_object_index(all_objects, fmc_name=''):
    by_name = {}
    for obj in all_objects:
        name  = obj.get('name', '')
        otype = obj.get('type', '')
        if not name:
            continue
        entry = {'id': obj.get('id',''), 'name': name, 'type': otype,
                 'value': '', 'members': [], 'fmc_source': fmc_name}
        if otype in ('Network', 'Host', 'FQDN', 'Range'):
            entry['value'] = obj.get('value', '')
        elif otype == 'ProtocolPortObject':
            proto = obj.get('protocol', '')
            port  = obj.get('port', '')
            entry['value'] = f'{proto}/{port}' if proto else port
        elif otype == 'ICMPv4Object':
            entry['value'] = f'ICMP/{obj.get("icmpType","any")}'
        elif otype in ('NetworkGroup', 'PortObjectGroup'):
            entry['_lits'] = [l.get('value','') for l in obj.get('literals', [])]
            entry['_mems'] = [m.get('name','')  for m in obj.get('objects',  [])]
        by_name[name] = entry

    def resolve(e, depth=0):
        if depth > 6: return []
        out = list(e.get('_lits', []))
        for mname in e.get('_mems', []):
            m = by_name.get(mname)
            if not m:
                out.append(f'UNRESOLVED:{mname}')
            elif m['type'] in ('Network','Host','Range','FQDN','ProtocolPortObject','ICMPv4Object'):
                out.append(m['value'])
            elif m['type'] in ('NetworkGroup','PortObjectGroup'):
                out.extend(resolve(m, depth + 1))
        return out

    for e in by_name.values():
        if e['type'] in ('NetworkGroup','PortObjectGroup'):
            e['members'] = resolve(e)
            e.pop('_lits', None)
            e.pop('_mems', None)
    return by_name


def pull_one_fmc(cfg, out_dir, limit, pull_policies, dry_run):
    name       = cfg['name']
    log(f'── {name} ({cfg["host"]}) ──')
    client = FMCClient(cfg['host'], cfg['user'], cfg['password'],
                       cfg.get('ssl_verify', True), cfg.get('domain',''))
    client.authenticate()
    ver = client.get_version()
    log(f'FMC version: {ver}', indent=2)
    if dry_run:
        log('Dry run — skipping pull.', indent=2)
        log()
        return None

    os.makedirs(out_dir, exist_ok=True)
    manifest = {
        'fmc_name': name, 'fmc_host': cfg['host'], 'fmc_version': ver,
        'domain_uuid': client.domain,
        'pull_utc': datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ'),
        'script': f'fmc_pull_objects.py v{VERSION}', 'counts': {},
    }
    all_objects = []

    for endpoint, filename, description in OBJECT_ENDPOINTS:
        log(f'{description}...', indent=1)
        items = client.fetch_all(endpoint, limit=limit)
        all_objects.extend(items)
        manifest['counts'][filename] = len(items)
        if items:
            with open(os.path.join(out_dir, filename), 'w', encoding='utf-8') as f:
                json.dump({'fmc': name, 'items': items, 'count': len(items)}, f, indent=2)
            log(f'{len(items):,} → {filename}', indent=2)
        else:
            log('(none / not supported)', indent=2)

    if pull_policies:
        log('Access Control Policies...', indent=1)
        policies = client.fetch_all(ACP_ENDPOINT, limit=limit)
        if policies:
            with open(os.path.join(out_dir, 'fmc_access_policies.json'), 'w', encoding='utf-8') as f:
                json.dump({'fmc': name, 'items': policies, 'count': len(policies)}, f, indent=2)
            log(f'{len(policies):,} policies → fmc_access_policies.json', indent=2)
            for p in policies:
                log(f'{p.get("name","")}  id={p.get("id","")}', indent=3)
            manifest['counts']['fmc_access_policies.json'] = len(policies)

    log('Building object index...', indent=1)
    index = build_object_index(all_objects, fmc_name=name)
    unresolved = sum(1 for v in index.values()
                     if any('UNRESOLVED:' in m for m in v.get('members', [])))
    with open(os.path.join(out_dir, 'fmc_object_index.json'), 'w', encoding='utf-8') as f:
        json.dump(index, f, indent=2)
    log(f'{len(index):,} objects indexed', indent=2)
    if unresolved:
        log(f'WARNING: {unresolved} group(s) with unresolved members', indent=2)
    manifest['counts']['fmc_object_index.json'] = len(index)
    manifest['unresolved_groups'] = unresolved
    with open(os.path.join(out_dir, 'fmc_pull_manifest.json'), 'w', encoding='utf-8') as f:
        json.dump(manifest, f, indent=2)

    pulled = sum(v for k,v in manifest['counts'].items() if 'index' not in k)
    log(f'Done. {pulled:,} objects pulled.', indent=1)
    log()
    return index


def merge_indexes(indexes_by_fmc, out_dir):
    merged = {}
    conflicts = {}
    for fmc_name, index in indexes_by_fmc.items():
        for name, entry in index.items():
            if name not in merged:
                merged[name] = dict(entry)
                merged[name]['fmc_sources'] = [fmc_name]
            else:
                ex = merged[name]
                ex_val  = ex.get('value')  or '|'.join(ex.get('members', []))
                new_val = entry.get('value') or '|'.join(entry.get('members', []))
                if ex_val != new_val and name not in conflicts:
                    conflicts[name] = {
                        'name': name, 'type': entry.get('type'), 'sources': {
                            s: ex_val for s in ex.get('fmc_sources', [])
                        }
                    }
                    conflicts[name]['sources'][fmc_name] = new_val
                if fmc_name not in ex.get('fmc_sources', []):
                    ex.setdefault('fmc_sources', []).append(fmc_name)

    with open(os.path.join(out_dir, 'fmc_merged_index.json'), 'w', encoding='utf-8') as f:
        json.dump(merged, f, indent=2)
    with open(os.path.join(out_dir, 'fmc_conflicts.json'), 'w', encoding='utf-8') as f:
        json.dump({'count': len(conflicts), 'conflicts': conflicts}, f, indent=2)
    return len(merged), len(conflicts)


def main():
    ap = argparse.ArgumentParser(
        description=f'fmc_pull_objects.py v{VERSION} — Pull FMC objects for CCD Platform',
    )
    ap.add_argument('--host',          default='',    help='FMC hostname or IP (single-FMC mode)')
    ap.add_argument('--user',          default='',    help='FMC username')
    ap.add_argument('--password',      default='',    help='FMC password (prompted if blank)')
    ap.add_argument('--domain',        default='',    help='Domain UUID override')
    ap.add_argument('--no-ssl-verify', action='store_true', help='Disable SSL verification')
    ap.add_argument('--config',        default='',    help='JSON config file (multi-FMC mode)')
    ap.add_argument('--out',           default='fmc-objects', help='Output directory')
    ap.add_argument('--limit',         type=int, default=1000, help='API page size (max 1000)')
    ap.add_argument('--dry-run',       action='store_true', help='Auth test only')
    ap.add_argument('--policies',      action='store_true', help='Also pull ACP policy list')
    args = ap.parse_args()

    log(f'fmc_pull_objects.py v{VERSION}')
    log()

    # Build target list
    targets = []
    if args.config:
        if not os.path.exists(args.config):
            log(f'ERROR: Config file not found: {args.config}'); sys.exit(1)
        with open(args.config) as f:
            targets = json.load(f)
        log(f'Config: {args.config}  ({len(targets)} FMC target(s))')
    elif args.host:
        targets = [{'name': args.host.replace('.', '-'), 'host': args.host,
                    'user': args.user, 'password': args.password,
                    'domain': args.domain, 'ssl_verify': not args.no_ssl_verify}]
    else:
        log('ERROR: Provide --host (single FMC) or --config (multi-FMC)')
        ap.print_help(); sys.exit(1)

    # Prompt for missing passwords up front
    for t in targets:
        if not t.get('password'):
            t['password'] = getpass.getpass(
                f'Password for {t["user"]}@{t["host"]} ({t["name"]}): ')

    log(f'Output: {os.path.abspath(args.out)}')
    log()

    indexes_by_fmc = {}
    summary_rows   = []

    for t in targets:
        fmc_out = os.path.join(args.out, t['name']) if len(targets) > 1 else args.out
        try:
            index = pull_one_fmc(t, fmc_out, args.limit, args.policies, args.dry_run)
            if index is not None:
                indexes_by_fmc[t['name']] = index
            summary_rows.append({
                'fmc': t['name'], 'host': t['host'],
                'status': 'OK', 'objects': len(index) if index else 0,
            })
        except Exception as e:
            log(f'ERROR on {t["name"]}: {e}')
            summary_rows.append({'fmc': t['name'], 'host': t['host'],
                                  'status': f'ERROR: {e}', 'objects': 0})

    if len(indexes_by_fmc) > 1 and not args.dry_run:
        log('── Merging cross-FMC indexes ──')
        merged_cnt, conflict_cnt = merge_indexes(indexes_by_fmc, args.out)
        log(f'Merged: {merged_cnt:,} unique objects')
        if conflict_cnt:
            log(f'Conflicts: {conflict_cnt} — review fmc_conflicts.json')
        log()

    if not args.dry_run and summary_rows:
        os.makedirs(args.out, exist_ok=True)
        with open(os.path.join(args.out, 'fmc_pull_summary.json'), 'w') as f:
            json.dump({'pull_utc': datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ'),
                       'fmcs': summary_rows}, f, indent=2)

    log('=== Summary ===')
    for row in summary_rows:
        objs = f"{row['objects']:,} objects" if row['objects'] else ''
        log(f'  {row["fmc"]:<22}  {row["host"]:<18}  {row["status"]}  {objs}')
    log()
    log('Done.')


if __name__ == '__main__':
    main()
