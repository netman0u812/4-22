# fmc_pull_objects.py — README

**Version:** 1.1  
**Owner:** CVS Health — Information Security, CCD Platform  
**Contact:** Michael Martin, Lead Director Information Security

---

## Purpose

This script pulls network objects, port objects, and security zone definitions
from one or more Cisco Firepower Management Center (FMC) instances via the FMC
REST API. The output files are used by the CCD Platform pipeline to translate
FMC Access Control Policy (ACP) rule exports — converting object name references
into actual IP addresses and CIDRs for IPAM enrichment and security analysis.

**You do not need to understand the CCD pipeline to run this script.** Your job
is to run it against the FMC instances listed in the config file and hand the
output directory back to the security team.

---

## Requirements

- Python 3.7 or later (no third-party packages required — pure stdlib)
- Network access to each FMC management IP on HTTPS (port 443)
- A read-only FMC user account (see FMC Access Requirements below)
- Run from a machine that can reach the FMC management network

Verify Python version:
```bash
python3 --version
```

---

## FMC Access Requirements

The script only reads data — it never writes to or modifies the FMC.

The FMC user account needs the following **read-only** permissions:

| Permission | Why |
|---|---|
| Access Control Policy — Read | To list ACP policies (if `--policies` is used) |
| Object Manager — Read | To pull all network and port objects |
| Device — Read | To pull security zone definitions |

In FMC: **System → Users → User Roles** — create or assign a role with the
above read permissions. A dedicated service account (`svc-ccd-readonly` or
similar) is recommended over using an admin account.

---

## Files

You should have received two files:

| File | Purpose |
|---|---|
| `fmc_pull_objects.py` | The pull script |
| `fmc_targets.json` | Config file listing the FMC instances to pull from |

---

## Configuration — fmc_targets.json

Before running, edit `fmc_targets.json` to set the correct FMC hostnames and
usernames. **Do not put passwords in this file** — the script will prompt for
each password securely at runtime.

```json
[
  {
    "name":       "Shea-FMC",
    "host":       "10.17.244.103",
    "user":       "svc-ccd-readonly",
    "password":   "",
    "domain":     "",
    "ssl_verify": false
  },
  {
    "name":       "RI-FMC",
    "host":       "10.17.245.200",
    "user":       "svc-ccd-readonly",
    "password":   "",
    "domain":     "",
    "ssl_verify": false
  }
]
```

### Config fields

| Field | Required | Description |
|---|---|---|
| `name` | Yes | A short label for this FMC. Used as the output subdirectory name. No spaces. |
| `host` | Yes | FMC management IP address or hostname |
| `user` | Yes | FMC username |
| `password` | No | Leave blank — script will prompt securely at runtime |
| `domain` | No | FMC domain UUID. Leave blank for auto-detection. |
| `ssl_verify` | No | Set `false` for FMCs with self-signed certificates (almost always needed). Default: `true` |

> **Note on `ssl_verify`:** FMC uses a self-signed SSL certificate by default.
> Unless your FMC has been configured with a CA-signed certificate, set this to
> `false`. The connection is still encrypted — this only disables certificate
> validation.

---

## Usage

### Step 1 — Test authentication (no data pulled)

Always run the dry-run first to confirm credentials and connectivity before
doing the full pull:

```bash
python3 fmc_pull_objects.py --config fmc_targets.json --dry-run
```

Expected output:
```
fmc_pull_objects.py v1.1

Config: fmc_targets.json  (2 FMC target(s))
Output: /path/to/fmc-objects

Password for svc-ccd-readonly@10.17.244.103 (Shea-FMC):
Password for svc-ccd-readonly@10.17.245.200 (RI-FMC):

── Shea-FMC (10.17.244.103) ──
    Auth OK  domain=e276abec-e0f2-11e3-8169-6d9ed49b625f
    FMC version: 7.2.5
    Dry run — skipping pull.

── RI-FMC (10.17.245.200) ──
    Auth OK  domain=a1b2c3d4-...
    FMC version: 7.2.3
    Dry run — skipping pull.

=== Summary ===
  Shea-FMC               10.17.244.103      OK
  RI-FMC                 10.17.245.200      OK
```

If you see `Auth failed HTTP 401`, the username or password is wrong.  
If you see `Cannot reach`, the FMC IP is not reachable from this machine.

### Step 2 — Full pull

```bash
python3 fmc_pull_objects.py \
  --config  fmc_targets.json \
  --out     fmc-objects/ \
  --policies
```

The `--policies` flag also pulls the list of Access Control Policy names and
UUIDs — the security team needs these to match the ACP export files.

The script will prompt for each FMC password, then run unattended. Depending
on the number of objects, a single FMC typically takes 2–10 minutes.

---

## Single FMC (no config file)

If you only need to pull from one FMC:

```bash
python3 fmc_pull_objects.py \
  --host  10.17.244.103 \
  --user  svc-ccd-readonly \
  --out   fmc-objects/ \
  --no-ssl-verify \
  --policies
```

---

## All Options

| Option | Default | Description |
|---|---|---|
| `--config FILE` | — | JSON config file (multi-FMC mode) |
| `--host IP` | — | FMC IP or hostname (single-FMC mode) |
| `--user USER` | — | FMC username |
| `--password PW` | (prompt) | FMC password. Omit — always prompt instead |
| `--domain UUID` | (auto) | Domain UUID override. Auto-detected if blank |
| `--out DIR` | `fmc-objects` | Output directory |
| `--limit N` | `1000` | API page size. Max 1000. Only reduce if you see timeout errors |
| `--no-ssl-verify` | off | Disable SSL certificate verification |
| `--dry-run` | off | Test auth only, pull nothing |
| `--policies` | off | Also pull ACP policy list (names + UUIDs) |

---

## Output Files

### Single FMC output
```
fmc-objects/
  fmc_network_objects.json      Subnet / CIDR objects
  fmc_host_objects.json         Host (/32) objects
  fmc_range_objects.json        IP range objects (e.g. 10.1.1.1-10.1.1.10)
  fmc_network_groups.json       Network group objects (raw, before resolution)
  fmc_port_objects.json         TCP/UDP port objects
  fmc_port_groups.json          Port group objects
  fmc_icmp_objects.json         ICMPv4 objects
  fmc_security_zones.json       Security zone definitions
  fmc_fqdn_objects.json         FQDN objects
  fmc_access_policies.json      ACP list (only if --policies was used)
  fmc_object_index.json         *** KEY FILE: name → resolved value/members ***
  fmc_pull_manifest.json        Pull metadata, timestamps, object counts
```

### Multi-FMC output
```
fmc-objects/
  Shea-FMC/                     Per-FMC subdirectory (same files as above)
    fmc_object_index.json
    fmc_pull_manifest.json
    ...
  RI-FMC/
    ...
  fmc_merged_index.json         *** KEY FILE: cross-FMC unified object lookup ***
  fmc_conflicts.json            Objects with same name but different values across FMCs
  fmc_pull_summary.json         Run summary (status, object counts per FMC)
```

### The key output files

**`fmc_object_index.json`** (single FMC) or **`fmc_merged_index.json`** (multi-FMC)
is the primary file the security team needs. It maps every object name to its
resolved IP/CIDR value:

```json
{
  "n_10.38.84.0": {
    "name": "n_10.38.84.0",
    "type": "Network",
    "value": "10.38.84.0/24",
    "fmc_source": "Shea-FMC"
  },
  "CVS_All_Internal": {
    "name": "CVS_All_Internal",
    "type": "NetworkGroup",
    "value": "",
    "members": ["10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16"],
    "fmc_source": "Shea-FMC"
  }
}
```

**`fmc_conflicts.json`** flags object names that exist on multiple FMCs with
different values — important for the CVS/Aetna environment where IP spaces overlap:

```json
{
  "count": 3,
  "conflicts": {
    "Internal_Hosts": {
      "name": "Internal_Hosts",
      "type": "NetworkGroup",
      "sources": {
        "Shea-FMC": "10.0.0.0/8|172.16.0.0/12",
        "RI-FMC":   "10.0.0.0/8|192.168.0.0/16"
      }
    }
  }
}
```

---

## Common Errors

### Auth failed HTTP 401
Wrong username or password. Verify credentials against the FMC UI.

### Cannot reach `https://x.x.x.x`: [Errno 61] Connection refused
The FMC is not reachable on port 443 from this machine. Check network
connectivity and firewall rules between your workstation and the FMC
management network.

### Auth failed HTTP 403
The account exists but lacks API access. In FMC: **System → Users** → confirm
the user has REST API access enabled on their role.

### WARNING: N group(s) with unresolved members
Some network group objects reference other objects that couldn't be found —
usually because those objects are in a different FMC domain or were deleted.
This is not a script error. The security team will handle UNRESOLVED entries.
Include the `fmc_object_index.json` as-is.

### Script hangs on a large FMC
Large environments (10,000+ objects) can take 10–20 minutes. The script
prints progress for each object type. Do not interrupt — let it complete.
If it consistently times out on a specific endpoint, try `--limit 500`.

---

## What the Script Does NOT Do

- It does not modify, delete, or write anything to the FMC
- It does not pull firewall logs or traffic data
- It does not pull the ACP rules themselves — those are exported separately
  from the FMC UI as JSON files and provided to the security team directly
- It does not require any FMC licence beyond standard REST API access

---

## Deliverable

When the pull is complete, zip the entire output directory and send it to the
security team along with `fmc_pull_manifest.json` (or `fmc_pull_summary.json`
for multi-FMC runs) so they can confirm what was pulled and when.

```bash
zip -r fmc-objects-$(date +%Y%m%d).zip fmc-objects/
```

---

## Revision History

| Version | Date | Change |
|---|---|---|
| 1.1 | 2026-04-19 | Multi-FMC support via config file, merged index, conflict detection |
| 1.0 | 2026-04-19 | Initial release — single FMC, token refresh, paginated pull |
